import React from 'react';

export default function StageDemo() {
  return (
    <div className="stage-demo">
      <div className="demo-header">
        <h1>🎯 Stagewise Development Demo</h1>
        <p>Welcome to Tarmaq's structured development approach</p>
      </div>

      <div className="demo-content">
        <div className="stage-overview">
          <h2>Current Development Status</h2>
          
          <div className="stage-cards">
            <div className="stage-card completed">
              <div className="stage-icon">✅</div>
              <h3>Stage 1: Foundation</h3>
              <p>Core application structure and essential components</p>
              <div className="stage-progress">
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: '100%' }}></div>
                </div>
                <span>4/4 components</span>
              </div>
            </div>

            <div className="stage-card in-progress">
              <div className="stage-icon">🔄</div>
              <h3>Stage 2: Component Library</h3>
              <p>Reusable UI components and design system</p>
              <div className="stage-progress">
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: '75%' }}></div>
                </div>
                <span>3/4 components</span>
              </div>
            </div>

            <div className="stage-card pending">
              <div className="stage-icon">⏳</div>
              <h3>Stage 3: Core Features</h3>
              <p>Main application functionality and business logic</p>
              <div className="stage-progress">
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: '0%' }}></div>
                </div>
                <span>0/4 components</span>
              </div>
            </div>

            <div className="stage-card pending">
              <div className="stage-icon">⏳</div>
              <h3>Stage 4: Enhancement</h3>
              <p>Performance, accessibility, and advanced features</p>
              <div className="stage-progress">
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: '0%' }}></div>
                </div>
                <span>0/4 components</span>
              </div>
            </div>

            <div className="stage-card pending">
              <div className="stage-icon">⏳</div>
              <h3>Stage 5: Polish & Launch</h3>
              <p>Testing, documentation, and deployment</p>
              <div className="stage-progress">
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: '0%' }}></div>
                </div>
                <span>0/4 components</span>
              </div>
            </div>
          </div>
        </div>

        <div className="demo-features">
          <h2>🎨 What You Can Do</h2>
          
          <div className="feature-list">
            <div className="feature-item">
              <h4>📊 Track Progress</h4>
              <p>Monitor completion status for each stage and component</p>
            </div>
            
            <div className="feature-item">
              <h4>🔄 Navigate Stages</h4>
              <p>Switch between different development phases seamlessly</p>
            </div>
            
            <div className="feature-item">
              <h4>🧩 Component Library</h4>
              <p>Explore and test reusable UI components in Stage 2</p>
            </div>
            
            <div className="feature-item">
              <h4>💾 Persistent Progress</h4>
              <p>Your progress is automatically saved and restored</p>
            </div>
          </div>
        </div>

        <div className="demo-cta">
          <h2>🚀 Ready to Start?</h2>
          <p>Use the stage navigation above to explore different development phases</p>
          <div className="cta-buttons">
            <button className="btn btn-primary">View Component Library</button>
            <button className="btn btn-secondary">Check Progress</button>
          </div>
        </div>
      </div>

      <style jsx>{`
        .stage-demo {
          max-width: 1200px;
          margin: 0 auto;
          padding: 2rem;
        }

        .demo-header {
          text-align: center;
          margin-bottom: 3rem;
        }

        .demo-header h1 {
          font-size: 2.5rem;
          color: #212529;
          margin-bottom: 0.5rem;
        }

        .demo-header p {
          font-size: 1.1rem;
          color: #6c757d;
        }

        .demo-content {
          display: flex;
          flex-direction: column;
          gap: 3rem;
        }

        .stage-overview h2 {
          font-size: 1.75rem;
          color: #212529;
          margin-bottom: 1.5rem;
        }

        .stage-cards {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1.5rem;
        }

        .stage-card {
          background: white;
          border: 1px solid #dee2e6;
          border-radius: 0.75rem;
          padding: 1.5rem;
          transition: all 0.2s ease;
        }

        .stage-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
        }

        .stage-card.completed {
          border-color: #28a745;
          background: linear-gradient(135deg, #f8fff9, #f0fff4);
        }

        .stage-card.in-progress {
          border-color: #ffc107;
          background: linear-gradient(135deg, #fffef8, #fffbf0);
        }

        .stage-card.pending {
          border-color: #e2e3e5;
          background: linear-gradient(135deg, #f8f9fa, #f1f3f4);
        }

        .stage-icon {
          font-size: 2rem;
          margin-bottom: 1rem;
        }

        .stage-card h3 {
          margin: 0 0 0.5rem 0;
          color: #212529;
          font-size: 1.25rem;
        }

        .stage-card p {
          margin: 0 0 1rem 0;
          color: #6c757d;
          line-height: 1.5;
        }

        .stage-progress {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .progress-bar {
          flex: 1;
          height: 0.5rem;
          background: #e9ecef;
          border-radius: 9999px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          transition: width 0.3s ease;
        }

        .stage-card.completed .progress-fill {
          background: linear-gradient(90deg, #28a745, #1e7e34);
        }

        .stage-card.in-progress .progress-fill {
          background: linear-gradient(90deg, #ffc107, #e0a800);
        }

        .stage-card.pending .progress-fill {
          background: #e2e3e5;
        }

        .stage-progress span {
          font-size: 0.875rem;
          color: #6c757d;
          font-weight: 600;
          min-width: 80px;
        }

        .demo-features h2 {
          font-size: 1.75rem;
          color: #212529;
          margin-bottom: 1.5rem;
        }

        .feature-list {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1.5rem;
        }

        .feature-item {
          background: white;
          border: 1px solid #dee2e6;
          border-radius: 0.5rem;
          padding: 1.5rem;
          transition: all 0.2s ease;
        }

        .feature-item:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
          border-color: #007bff;
        }

        .feature-item h4 {
          margin: 0 0 0.75rem 0;
          color: #212529;
          font-size: 1.1rem;
        }

        .feature-item p {
          margin: 0;
          color: #6c757d;
          line-height: 1.5;
        }

        .demo-cta {
          text-align: center;
          background: linear-gradient(135deg, #f8f9fa, #e9ecef);
          border-radius: 0.75rem;
          padding: 2rem;
        }

        .demo-cta h2 {
          font-size: 1.75rem;
          color: #212529;
          margin-bottom: 0.5rem;
        }

        .demo-cta p {
          font-size: 1.1rem;
          color: #6c757d;
          margin-bottom: 1.5rem;
        }

        .cta-buttons {
          display: flex;
          gap: 1rem;
          justify-content: center;
          flex-wrap: wrap;
        }

        .btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          padding: 0.75rem 1.5rem;
          border-radius: 0.5rem;
          font-weight: 600;
          border: 1px solid transparent;
          transition: all 0.2s ease;
          cursor: pointer;
          font-size: 0.9rem;
          text-decoration: none;
        }

        .btn-primary {
          background: #007bff;
          color: white;
        }

        .btn-primary:hover {
          background: #0056b3;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
        }

        .btn-secondary {
          background: #6c757d;
          color: white;
        }

        .btn-secondary:hover {
          background: #545b62;
          transform: translateY(-1px);
        }

        @media (max-width: 768px) {
          .stage-cards {
            grid-template-columns: 1fr;
          }
          
          .feature-list {
            grid-template-columns: 1fr;
          }
          
          .cta-buttons {
            flex-direction: column;
            align-items: center;
          }
        }
      `}</style>
    </div>
  );
}
