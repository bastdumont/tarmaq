import React, { useState, useEffect } from 'react';

// Stage configuration for the Tarmaq project
const STAGES = {
  foundation: {
    id: 'foundation',
    name: 'Foundation',
    description: 'Basic project structure and core components',
    status: 'completed',
    components: ['App', 'Header', 'Hero', 'Footer']
  },
  components: {
    id: 'components',
    name: 'Component Library',
    description: 'Reusable UI components and design system',
    status: 'in-progress',
    components: ['Button', 'Card', 'Grid', 'Navigation']
  },
  features: {
    id: 'features',
    name: 'Core Features',
    description: 'Main application functionality',
    status: 'pending',
    components: ['Programs', 'Agenda', 'Partners', 'Newsletter']
  },
  enhancement: {
    id: 'enhancement',
    name: 'Enhancement',
    description: 'Advanced features and optimizations',
    status: 'pending',
    components: ['Animations', 'Performance', 'Accessibility', 'SEO']
  },
  polish: {
    id: 'polish',
    name: 'Polish & Launch',
    description: 'Final touches and deployment preparation',
    status: 'pending',
    components: ['Testing', 'Documentation', 'Deployment', 'Monitoring']
  }
};

export default function StageManager({ children }) {
  const [currentStage, setCurrentStage] = useState('foundation');
  const [stageProgress, setStageProgress] = useState({});
  const [showStageInfo, setShowStageInfo] = useState(false);

  // Initialize stage progress
  useEffect(() => {
    const savedProgress = localStorage.getItem('tarmaq-stage-progress');
    if (savedProgress) {
      setStageProgress(JSON.parse(savedProgress));
    } else {
      // Set default progress
      const defaultProgress = Object.keys(STAGES).reduce((acc, stageId) => {
        acc[stageId] = {
          completed: stageId === 'foundation' ? STAGES[stageId].components.length : 0,
          total: STAGES[stageId].components.length,
          status: STAGES[stageId].status
        };
        return acc;
      }, {});
      setStageProgress(defaultProgress);
    }
  }, []);

  // Save progress to localStorage
  useEffect(() => {
    localStorage.setItem('tarmaq-stage-progress', JSON.stringify(stageProgress));
  }, [stageProgress]);

  const updateStageProgress = (stageId, componentName, completed = true) => {
    setStageProgress(prev => {
      const stage = prev[stageId];
      if (!stage) return prev;

      const newCompleted = completed 
        ? Math.min(stage.completed + 1, stage.total)
        : Math.max(stage.completed - 1, 0);

      return {
        ...prev,
        [stageId]: {
          ...stage,
          completed: newCompleted,
          status: newCompleted === stage.total ? 'completed' : 'in-progress'
        }
      };
    });
  };

  const getStageStatus = (stageId) => {
    const stage = stageProgress[stageId];
    if (!stage) return 'pending';
    
    if (stage.completed === stage.total) return 'completed';
    if (stage.completed > 0) return 'in-progress';
    return 'pending';
  };

  const getOverallProgress = () => {
    const totalStages = Object.keys(STAGES).length;
    const completedStages = Object.values(stageProgress).filter(
      stage => stage.status === 'completed'
    ).length;
    return Math.round((completedStages / totalStages) * 100);
  };

  return (
    <div className="stage-manager">
      {/* Stage Progress Bar */}
      <div className="stage-progress-bar">
        <div className="progress-overview">
          <span className="progress-text">Project Progress: {getOverallProgress()}%</span>
          <button 
            className="stage-info-toggle"
            onClick={() => setShowStageInfo(!showStageInfo)}
            aria-label="Toggle stage information"
          >
            {showStageInfo ? 'Hide' : 'Show'} Stages
          </button>
        </div>
        
        {showStageInfo && (
          <div className="stages-overview">
            {Object.values(STAGES).map((stage) => (
              <div 
                key={stage.id} 
                className={`stage-item ${getStageStatus(stage.id)} ${currentStage === stage.id ? 'active' : ''}`}
                onClick={() => setCurrentStage(stage.id)}
              >
                <div className="stage-header">
                  <h3>{stage.name}</h3>
                  <span className="stage-status">{getStageStatus(stage.id)}</span>
                </div>
                <p className="stage-description">{stage.description}</p>
                <div className="stage-progress">
                  <div className="progress-bar">
                    <div 
                      className="progress-fill" 
                      style={{ 
                        width: `${(stageProgress[stage.id]?.completed || 0) / (stageProgress[stage.id]?.total || 1) * 100}%` 
                      }}
                    />
                  </div>
                  <span className="progress-text">
                    {stageProgress[stage.id]?.completed || 0} / {stageProgress[stage.id]?.total || 0}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Stage Content */}
      <div className="stage-content">
        {children}
      </div>

      {/* Stage Navigation */}
      <div className="stage-navigation">
        <button 
          className="nav-btn prev"
          onClick={() => {
            const stageIds = Object.keys(STAGES);
            const currentIndex = stageIds.indexOf(currentStage);
            if (currentIndex > 0) {
              setCurrentStage(stageIds[currentIndex - 1]);
            }
          }}
          disabled={currentStage === Object.keys(STAGES)[0]}
        >
          ← Previous Stage
        </button>
        
        <span className="current-stage">
          {STAGES[currentStage]?.name}
        </span>
        
        <button 
          className="nav-btn next"
          onClick={() => {
            const stageIds = Object.keys(STAGES);
            const currentIndex = stageIds.indexOf(currentStage);
            if (currentIndex < stageIds.length - 1) {
              setCurrentStage(stageIds[currentIndex + 1]);
            }
          }}
          disabled={currentStage === Object.keys(STAGES)[Object.keys(STAGES).length - 1]}
        >
          Next Stage →
        </button>
      </div>

      <style jsx>{`
        .stage-manager {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
        }

        .stage-progress-bar {
          background: #f8f9fa;
          border-bottom: 1px solid #e9ecef;
          padding: 1rem;
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .progress-overview {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }

        .progress-text {
          font-weight: 600;
          color: #495057;
        }

        .stage-info-toggle {
          background: #007bff;
          color: white;
          border: none;
          padding: 0.5rem 1rem;
          border-radius: 0.375rem;
          cursor: pointer;
          font-size: 0.875rem;
        }

        .stage-info-toggle:hover {
          background: #0056b3;
        }

        .stages-overview {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1rem;
        }

        .stage-item {
          background: white;
          border: 1px solid #dee2e6;
          border-radius: 0.5rem;
          padding: 1rem;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .stage-item:hover {
          border-color: #007bff;
          box-shadow: 0 2px 8px rgba(0, 123, 255, 0.1);
        }

        .stage-item.active {
          border-color: #007bff;
          background: #f8f9ff;
        }

        .stage-item.completed {
          border-color: #28a745;
          background: #f8fff9;
        }

        .stage-item.in-progress {
          border-color: #ffc107;
          background: #fffef8;
        }

        .stage-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 0.5rem;
        }

        .stage-header h3 {
          margin: 0;
          font-size: 1rem;
          color: #212529;
        }

        .stage-status {
          font-size: 0.75rem;
          padding: 0.25rem 0.5rem;
          border-radius: 9999px;
          text-transform: uppercase;
          font-weight: 600;
        }

        .stage-item.completed .stage-status {
          background: #d4edda;
          color: #155724;
        }

        .stage-item.in-progress .stage-status {
          background: #fff3cd;
          color: #856404;
        }

        .stage-item.pending .stage-status {
          background: #e2e3e5;
          color: #6c757d;
        }

        .stage-description {
          font-size: 0.875rem;
          color: #6c757d;
          margin: 0 0 1rem 0;
          line-height: 1.4;
        }

        .stage-progress {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .progress-bar {
          flex: 1;
          height: 0.5rem;
          background: #e9ecef;
          border-radius: 9999px;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #007bff, #0056b3);
          transition: width 0.3s ease;
        }

        .stage-item.completed .progress-fill {
          background: linear-gradient(90deg, #28a745, #1e7e34);
        }

        .stage-item.in-progress .progress-fill {
          background: linear-gradient(90deg, #ffc107, #e0a800);
        }

        .stage-content {
          flex: 1;
          padding: 2rem;
        }

        .stage-navigation {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem 2rem;
          background: #f8f9fa;
          border-top: 1px solid #e9ecef;
        }

        .nav-btn {
          background: #007bff;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 0.375rem;
          cursor: pointer;
          font-weight: 600;
          transition: all 0.2s ease;
        }

        .nav-btn:hover:not(:disabled) {
          background: #0056b3;
          transform: translateY(-1px);
        }

        .nav-btn:disabled {
          background: #6c757d;
          cursor: not-allowed;
          opacity: 0.6;
        }

        .current-stage {
          font-weight: 600;
          color: #495057;
          font-size: 1.1rem;
        }

        @media (max-width: 768px) {
          .stages-overview {
            grid-template-columns: 1fr;
          }
          
          .stage-navigation {
            flex-direction: column;
            gap: 1rem;
            text-align: center;
          }
        }
      `}</style>
    </div>
  );
}
