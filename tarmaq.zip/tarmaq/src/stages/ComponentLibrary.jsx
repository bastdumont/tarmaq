import React, { useState } from 'react';

// Reusable Button Component
const Button = ({ 
  children, 
  variant = 'primary', 
  size = 'medium', 
  disabled = false, 
  onClick, 
  className = '',
  ...props 
}) => {
  const baseClasses = 'btn';
  const variantClasses = {
    primary: 'btn-primary',
    secondary: 'btn-secondary',
    ghost: 'btn-ghost',
    grad: 'btn-grad',
    outline: 'btn-outline'
  };
  const sizeClasses = {
    small: 'btn-sm',
    medium: 'btn-md',
    large: 'btn-lg'
  };

  const classes = `${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${className}`.trim();

  return (
    <button 
      className={classes} 
      disabled={disabled} 
      onClick={onClick}
      {...props}
    >
      {children}
    </button>
  );
};

// Reusable Card Component
const Card = ({ 
  children, 
  variant = 'default', 
  className = '', 
  onClick,
  ...props 
}) => {
  const baseClasses = 'card';
  const variantClasses = {
    default: 'card-default',
    elevated: 'card-elevated',
    interactive: 'card-interactive'
  };

  const classes = `${baseClasses} ${variantClasses[variant]} ${className}`.trim();

  return (
    <div 
      className={classes} 
      onClick={onClick}
      {...props}
    >
      {children}
    </div>
  );
};

// Reusable Grid Component
const Grid = ({ 
  children, 
  columns = 3, 
  gap = 'medium', 
  className = '',
  ...props 
}) => {
  const gapClasses = {
    small: 'gap-sm',
    medium: 'gap-md',
    large: 'gap-lg'
  };

  const classes = `grid grid-${columns} ${gapClasses[gap]} ${className}`.trim();

  return (
    <div className={classes} {...props}>
      {children}
    </div>
  );
};

// Component Showcase
export default function ComponentLibrary() {
  const [selectedComponent, setSelectedComponent] = useState('button');

  const components = {
    button: {
      name: 'Button',
      description: 'Flexible button component with multiple variants and sizes',
      examples: [
        { variant: 'primary', size: 'medium', label: 'Primary Button' },
        { variant: 'secondary', size: 'medium', label: 'Secondary Button' },
        { variant: 'ghost', size: 'medium', label: 'Ghost Button' },
        { variant: 'grad', size: 'medium', label: 'Gradient Button' },
        { variant: 'outline', size: 'medium', label: 'Outline Button' }
      ]
    },
    card: {
      name: 'Card',
      description: 'Versatile card component for displaying content in containers',
      examples: [
        { variant: 'default', content: 'Default Card' },
        { variant: 'elevated', content: 'Elevated Card' },
        { variant: 'interactive', content: 'Interactive Card' }
      ]
    },
    grid: {
      name: 'Grid',
      description: 'Responsive grid system for layout management',
      examples: [
        { columns: 2, content: '2 Column Grid' },
        { columns: 3, content: '3 Column Grid' },
        { columns: 4, content: '4 Column Grid' }
      ]
    }
  };

  const renderComponentExample = (componentType) => {
    const component = components[componentType];
    
    switch (componentType) {
      case 'button':
        return (
          <div className="component-examples">
            <h3>{component.name}</h3>
            <p>{component.description}</p>
            <div className="examples-grid">
              {component.examples.map((example, index) => (
                <div key={index} className="example-item">
                  <Button 
                    variant={example.variant} 
                    size={example.size}
                  >
                    {example.label}
                  </Button>
                  <code className="code-snippet">
                    {`<Button variant="${example.variant}" size="${example.size}">${example.label}</Button>`}
                  </code>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'card':
        return (
          <div className="component-examples">
            <h3>{component.name}</h3>
            <p>{component.description}</p>
            <div className="examples-grid">
              {component.examples.map((example, index) => (
                <div key={index} className="example-item">
                  <Card variant={example.variant}>
                    <h4>Card Title</h4>
                    <p>{example.content}</p>
                    <Button variant="primary" size="small">Action</Button>
                  </Card>
                  <code className="code-snippet">
                    {`<Card variant="${example.variant}">...</Card>`}
                  </code>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'grid':
        return (
          <div className="component-examples">
            <h3>{component.name}</h3>
            <p>{component.description}</p>
            <div className="examples-grid">
              {component.examples.map((example, index) => (
                <div key={index} className="example-item">
                  <Grid columns={example.columns} className="demo-grid">
                    {Array.from({ length: example.columns * 2 }, (_, i) => (
                      <div key={i} className="grid-item">
                        Item {i + 1}
                      </div>
                    ))}
                  </Grid>
                  <code className="code-snippet">
                    {`<Grid columns={${example.columns}}>...</Grid>`}
                  </code>
                </div>
              ))}
            </div>
          </div>
        );
      
      default:
        return <div>Select a component to view examples</div>;
    }
  };

  return (
    <div className="component-library">
      <div className="library-header">
        <h1>Component Library</h1>
        <p>Stage 2: Building reusable UI components for consistent design</p>
      </div>

      <div className="library-content">
        <div className="component-sidebar">
          <h3>Components</h3>
          <nav className="component-nav">
            {Object.keys(components).map((componentKey) => (
              <button
                key={componentKey}
                className={`nav-item ${selectedComponent === componentKey ? 'active' : ''}`}
                onClick={() => setSelectedComponent(componentKey)}
              >
                {components[componentKey].name}
              </button>
            ))}
          </nav>
        </div>

        <div className="component-main">
          {renderComponentExample(selectedComponent)}
        </div>
      </div>

      <style jsx>{`
        .component-library {
          max-width: 1200px;
          margin: 0 auto;
          padding: 2rem;
        }

        .library-header {
          text-align: center;
          margin-bottom: 3rem;
        }

        .library-header h1 {
          font-size: 2.5rem;
          color: #212529;
          margin-bottom: 0.5rem;
        }

        .library-header p {
          font-size: 1.1rem;
          color: #6c757d;
        }

        .library-content {
          display: grid;
          grid-template-columns: 250px 1fr;
          gap: 3rem;
          min-height: 600px;
        }

        .component-sidebar {
          background: #f8f9fa;
          border-radius: 0.5rem;
          padding: 1.5rem;
          height: fit-content;
        }

        .component-sidebar h3 {
          margin: 0 0 1rem 0;
          color: #495057;
          font-size: 1.1rem;
        }

        .component-nav {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .nav-item {
          background: white;
          border: 1px solid #dee2e6;
          border-radius: 0.375rem;
          padding: 0.75rem 1rem;
          text-align: left;
          cursor: pointer;
          transition: all 0.2s ease;
          font-size: 0.9rem;
        }

        .nav-item:hover {
          border-color: #007bff;
          background: #f8f9ff;
        }

        .nav-item.active {
          border-color: #007bff;
          background: #007bff;
          color: white;
        }

        .component-main {
          background: white;
          border: 1px solid #dee2e6;
          border-radius: 0.5rem;
          padding: 2rem;
        }

        .component-examples h3 {
          margin: 0 0 0.5rem 0;
          color: #212529;
          font-size: 1.5rem;
        }

        .component-examples p {
          margin: 0 0 2rem 0;
          color: #6c757d;
          line-height: 1.6;
        }

        .examples-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
        }

        .example-item {
          border: 1px solid #e9ecef;
          border-radius: 0.5rem;
          padding: 1.5rem;
          background: #f8f9fa;
        }

        .code-snippet {
          display: block;
          background: #212529;
          color: #f8f9fa;
          padding: 1rem;
          border-radius: 0.375rem;
          font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
          font-size: 0.875rem;
          margin-top: 1rem;
          overflow-x: auto;
        }

        .demo-grid {
          margin-bottom: 1rem;
        }

        .grid-item {
          background: #007bff;
          color: white;
          padding: 1rem;
          border-radius: 0.375rem;
          text-align: center;
          font-weight: 600;
        }

        /* Button variants */
        .btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          padding: 12px 18px;
          border-radius: 14px;
          font-weight: 700;
          border: 1px solid transparent;
          transition: all 0.2s ease;
          cursor: pointer;
          font-size: 14px;
          text-decoration: none;
        }

        .btn:focus {
          outline: 2px solid transparent;
          box-shadow: 0 0 0 4px rgba(0, 123, 255, 0.18);
        }

        .btn-primary {
          background: #007bff;
          color: white;
        }

        .btn-primary:hover {
          background: #0056b3;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
        }

        .btn-secondary {
          background: #6c757d;
          color: white;
        }

        .btn-secondary:hover {
          background: #545b62;
          transform: translateY(-1px);
        }

        .btn-ghost {
          background: rgba(255, 255, 255, 0.8);
          border-color: #dee2e6;
          color: #495057;
        }

        .btn-ghost:hover {
          background: white;
          border-color: #007bff;
          color: #007bff;
          transform: translateY(-1px);
        }

        .btn-grad {
          background: linear-gradient(135deg, #007bff, #0056b3);
          color: white;
        }

        .btn-grad:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
        }

        .btn-outline {
          background: transparent;
          border-color: #007bff;
          color: #007bff;
        }

        .btn-outline:hover {
          background: #007bff;
          color: white;
          transform: translateY(-1px);
        }

        .btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
          transform: none !important;
        }

        /* Card variants */
        .card {
          background: white;
          border: 1px solid #dee2e6;
          border-radius: 0.5rem;
          padding: 1.5rem;
          transition: all 0.2s ease;
        }

        .card h4 {
          margin: 0 0 0.5rem 0;
          color: #212529;
        }

        .card p {
          margin: 0 0 1rem 0;
          color: #6c757d;
        }

        .card-elevated {
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .card-interactive {
          cursor: pointer;
        }

        .card-interactive:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
        }

        /* Grid system */
        .grid {
          display: grid;
          gap: 1rem;
        }

        .grid-2 { grid-template-columns: repeat(2, 1fr); }
        .grid-3 { grid-template-columns: repeat(3, 1fr); }
        .grid-4 { grid-template-columns: repeat(4, 1fr); }

        .gap-sm { gap: 0.5rem; }
        .gap-md { gap: 1rem; }
        .gap-lg { gap: 1.5rem; }

        @media (max-width: 768px) {
          .library-content {
            grid-template-columns: 1fr;
            gap: 2rem;
          }
          
          .examples-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}
