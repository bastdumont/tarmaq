# Tarmaq - Stagewise Development with Sonnet

A React-based web application for Tarmaq, an accelerator of opportunities for young people in Geneva, built using a stagewise development approach with Sonnet AI integration.

## 🚀 Stagewise Development Approach

This project follows a structured, incremental development methodology that breaks down the development process into clear, manageable stages. Each stage builds upon the previous one, ensuring a solid foundation and systematic feature delivery.

### 📋 Development Stages

#### Stage 1: Foundation ✅
- **Status**: Completed
- **Focus**: Basic project structure and core components
- **Components**: App, Header, Hero, Footer
- **Description**: Establishes the core application structure with essential UI components and styling

#### Stage 2: Component Library 🔄
- **Status**: In Progress
- **Focus**: Reusable UI components and design system
- **Components**: Button, Card, Grid, Navigation
- **Description**: Building a comprehensive component library for consistent design and development

#### Stage 3: Core Features ⏳
- **Status**: Pending
- **Focus**: Main application functionality
- **Components**: Programs, Agenda, Partners, Newsletter
- **Description**: Implementing the core business logic and user interactions

#### Stage 4: Enhancement ⏳
- **Status**: Pending
- **Focus**: Advanced features and optimizations
- **Components**: Animations, Performance, Accessibility, SEO
- **Description**: Adding polish, performance improvements, and accessibility features

#### Stage 5: Polish & Launch ⏳
- **Status**: Pending
- **Focus**: Final touches and deployment preparation
- **Components**: Testing, Documentation, Deployment, Monitoring
- **Description**: Quality assurance, documentation, and production deployment

## 🛠️ Technology Stack

- **Frontend**: React 18 with Vite
- **Styling**: CSS-in-JS with styled-jsx
- **Development**: Stagewise development methodology
- **AI Integration**: Sonnet AI for development assistance
- **Build Tool**: Vite for fast development and building
- **Testing**: Vitest for unit testing

## 🚀 Getting Started

### Prerequisites
- Node.js 16+ 
- npm or yarn

### Installation
```bash
# Clone the repository
git clone <repository-url>
cd tarmaq

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Run tests
npm test
```

## 📁 Project Structure

```
tarmaq/
├── src/
│   ├── stages/           # Stage-specific components
│   │   ├── StageManager.jsx      # Main stage management system
│   │   └── ComponentLibrary.jsx  # Stage 2 component showcase
│   ├── App.jsx           # Main application with stage routing
│   ├── main.jsx          # Application entry point
│   └── assets/           # Static assets
├── public/               # Public assets
├── package.json          # Dependencies and scripts
└── README.md            # This file
```

## 🎯 Stage Management

The application includes a built-in stage management system that provides:

- **Progress Tracking**: Visual progress indicators for each stage
- **Stage Navigation**: Easy switching between development stages
- **Component Showcase**: Interactive component library for Stage 2
- **Progress Persistence**: Local storage for tracking development progress

### Using the Stage Manager

1. **View Progress**: Click "Show Stages" to see all development stages
2. **Navigate Stages**: Use the navigation buttons to move between stages
3. **Track Progress**: Monitor completion status and component progress
4. **Focus Development**: Work on one stage at a time for better organization

## 🔧 Development Workflow

### Stage 1: Foundation
- ✅ Basic React app structure
- ✅ Header with navigation
- ✅ Hero section with call-to-action
- ✅ Footer with contact information
- ✅ Responsive design and styling

### Stage 2: Component Library (Current)
- 🔄 Button component with variants
- 🔄 Card component with different styles
- 🔄 Grid system for layouts
- ⏳ Navigation components
- ⏳ Form components

### Stage 3: Core Features (Next)
- ⏳ Programs management system
- ⏳ Interactive agenda/calendar
- ⏳ Partners portal
- ⏳ Newsletter subscription system

## 🎨 Design System

The project follows a consistent design system with:

- **Color Palette**: Brand colors with semantic variations
- **Typography**: Inter font family with consistent sizing
- **Spacing**: 8px grid system for consistent layouts
- **Components**: Reusable UI components with variants
- **Responsiveness**: Mobile-first responsive design

## 🧪 Testing

```bash
# Run tests in watch mode
npm run test:watch

# Run tests once
npm test
```

## 📦 Building and Deployment

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

## 🤝 Contributing

1. **Follow Stages**: Work within the current development stage
2. **Component Consistency**: Use the established design system
3. **Testing**: Ensure components work across different screen sizes
4. **Documentation**: Update this README when adding new features

## 📱 Responsive Design

The application is built with a mobile-first approach and includes:
- Responsive grid layouts
- Mobile navigation menu
- Touch-friendly interactions
- Optimized typography for all screen sizes

## 🔮 Future Enhancements

- **Stage 4**: Performance optimizations and accessibility improvements
- **Stage 5**: Advanced testing and deployment automation
- **Beyond**: Additional features based on user feedback and requirements

## 📄 License

This project is part of the Tarmaq initiative by Perspectives Jeunesse in Geneva.

---

**Current Stage**: Component Library (Stage 2)  
**Overall Progress**: 40%  
**Next Milestone**: Core Features Implementation
